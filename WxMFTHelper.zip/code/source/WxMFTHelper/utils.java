/*
* Copyright © 2017 - 2018 Software AG, Darmstadt, Germany and/or its licensors
*
* SPDX-License-Identifier: Apache-2.0
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.                                                            
*
*/

package WxMFTHelper;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
// --- <<IS-END-IMPORTS>> ---

public final class utils

{
	// ---( internal utility methods )---

	final static utils _instance = new utils();

	static utils _newInstance() { return new utils(); }

	static utils _cast(Object o) { return (utils)o; }

	// ---( server methods )---




	public static final void byteArrayToHexString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(byteArrayToHexString)>> ---
		// @sigtype java 3.5
		// [i] object:0:required byteArray
		// [o] field:0:required byteArrayAsString
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			byte[]	byteArray = (byte[]) IDataUtil.get( pipelineCursor, "byteArray" );
		pipelineCursor.destroy();
		
		String byteArrayAsString = javax.xml.bind.DatatypeConverter.printHexBinary(byteArray);
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		IDataUtil.put( pipelineCursor_1, "byteArrayAsString", byteArrayAsString );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void checkURL (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(checkURL)>> ---
		// @sigtype java 3.5
		// [i] field:0:required url
		// [o] field:0:required isOK
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	url = IDataUtil.getString( pipelineCursor, "url" );
		pipelineCursor.destroy();
		boolean isOK = false;
		try {
			URI uri = new URI(url);
			isOK = (uri.getPort() != -1);
		} catch (URISyntaxException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "isOK", Boolean.toString(isOK) );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}
}

