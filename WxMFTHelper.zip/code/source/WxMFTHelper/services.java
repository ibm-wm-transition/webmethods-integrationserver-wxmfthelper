/*
* Copyright © 2017 - 2018 Software AG, Darmstadt, Germany and/or its licensors
*
* SPDX-License-Identifier: Apache-2.0
*
*   Licensed under the Apache License, Version 2.0 (the "License");
*   you may not use this file except in compliance with the License.
*   You may obtain a copy of the License at
*
*       http://www.apache.org/licenses/LICENSE-2.0
*
*   Unless required by applicable law or agreed to in writing, software
*   distributed under the License is distributed on an "AS IS" BASIS,
*   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
*   See the License for the specific language governing permissions and
*   limitations under the License.                                                            
*
*/


package WxMFTHelper;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2016-06-23 11:56:32 CEST
// -----( ON-HOST: at2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import javax.xml.bind.DatatypeConverter;
// --- <<IS-END-IMPORTS>> ---

public final class services

{
	// ---( internal utility methods )---

	final static services _instance = new services();

	static services _newInstance() { return new services(); }

	static services _cast(Object o) { return (services)o; }

	// ---( server methods )---




	public static final void createMD5 (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createMD5)>> ---
		// @sigtype java 3.5
		// [i] object:0:required instream
		// [i] object:0:required inbytes
		// [o] object:0:required md5
		// [o] field:0:required md5HexString
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			InputStream	instream = (InputStream) IDataUtil.get( pipelineCursor, "instream" );
			byte[]	inbytes = (byte[]) IDataUtil.get( pipelineCursor, "inbytes" );
		pipelineCursor.destroy();
		
		byte[] md5 = null;
		
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			if (instream != null) {
				byte[] buf = new byte[65536];
				int bytesread;
				try {
					while ((bytesread=instream.read(buf)) > 0){
						md.update(buf, 0, bytesread);
					}
					md5 = md.digest();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else if (inbytes != null) {
				md.update(inbytes);
				md5 = md.digest();
			}
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		// pipeline
		IDataCursor pipelineCursorOut = pipeline.getCursor();
		//Object md5 = new Object();
		IDataUtil.put( pipelineCursorOut, "md5", md5 );
		IDataUtil.put( pipelineCursorOut, "md5HexString", (md5 != null) ? DatatypeConverter.printHexBinary(md5).toLowerCase() : null);
		pipelineCursor.destroy();
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void verifyMD5 (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(verifyMD5)>> ---
		// @sigtype java 3.5
		// [i] object:0:required instream
		// [i] object:0:required inbytes
		// [i] object:0:required md5
		// [i] field:0:required md5AsHexString
		// [o] field:0:required isValid {"true","false"}
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			InputStream	instream = (InputStream) IDataUtil.get( pipelineCursor, "instream" );
			byte[]	inbytes = (byte[]) IDataUtil.get( pipelineCursor, "inbytes" );
			byte[]	md5 = (byte[]) IDataUtil.get( pipelineCursor, "md5" );
			String	md5AsHexString = IDataUtil.getString( pipelineCursor, "md5AsHexString" );
		pipelineCursor.destroy();
		
		byte[] this_md5 = null;
		boolean isValid = false;
		
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			if (instream != null) {
				byte[] buf = new byte[65536];
				int bytesread;
				try {
					while ((bytesread=instream.read(buf)) > 0){
						md.update(buf, 0, bytesread);
					}
					this_md5 = md.digest();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else if (inbytes != null) {
				md.update(inbytes);
				this_md5 = md.digest();
			}
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if (this_md5 != null) {
			if (md5 != null) {
				isValid = Arrays.equals(this_md5, md5);
			} else if (md5AsHexString != null){
				isValid = md5AsHexString.equalsIgnoreCase(DatatypeConverter.printHexBinary(this_md5));
			}
		}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "isValid", new Boolean(isValid).toString() );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}
}

